import React, { useState } from "react";
import FashionCard from "./components/FashionCard";

const categories = ["Todos", "Vestidos", "Chaquetas", "Pantalones"];

const fashionItems = [
  {
    id: 1,
    name: "Vestido Elegante",
    description: "Perfecto para eventos formales.",
    price: "$120",
    category: "Vestidos",
    image: "https://via.placeholder.com/300x400?text=Vestido+Elegante",
  },
  {
    id: 2,
    name: "Chaqueta Casual",
    description: "Estilo y comodidad para el día a día.",
    price: "$85",
    category: "Chaquetas",
    image: "https://via.placeholder.com/300x400?text=Chaqueta+Casual",
  },
  {
    id: 3,
    name: "Pantalones Modernos",
    description: "Diseño contemporáneo y ajuste perfecto.",
    price: "$70",
    category: "Pantalones",
    image: "https://via.placeholder.com/300x400?text=Pantalones+Modernos",
  },
];

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState("Todos");

  const filteredItems =
    selectedCategory === "Todos"
      ? fashionItems
      : fashionItems.filter((item) => item.category === selectedCategory);

  return (
    <div className="p-6 bg-pink-50 min-h-screen">
      <h1 className="text-4xl font-bold text-center text-pink-800 mb-6">MODA BO</h1>

      <div className="flex justify-center gap-4 mb-8">
        {categories.map((cat) => (
          <button
            key={cat}
            className={\`px-4 py-2 rounded-xl \${selectedCategory === cat
              ? "bg-pink-600 text-white"
              : "bg-white text-pink-600 border border-pink-600"}\`}
            onClick={() => setSelectedCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <FashionCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}
