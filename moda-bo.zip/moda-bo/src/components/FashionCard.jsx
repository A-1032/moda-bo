import React from "react";
import { motion } from "framer-motion";

export default function FashionCard({ item }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="rounded-2xl shadow-lg bg-white"
    >
      <img src={item.image} alt={item.name} className="w-full h-80 object-cover" />
      <div className="p-4">
        <h2 className="text-xl font-semibold text-pink-700">{item.name}</h2>
        <p className="text-sm text-gray-600 mb-2">{item.description}</p>
        <p className="text-lg font-bold text-pink-900">{item.price}</p>
        <button className="mt-4 w-full bg-pink-600 hover:bg-pink-700 text-white py-2 rounded-xl">
          Ver más
        </button>
      </div>
    </motion.div>
  );
}
